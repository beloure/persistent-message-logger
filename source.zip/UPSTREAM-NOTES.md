# Source review and changes

The working reference is Unbound's first-party Message Logger, linked by its official addon page. The source at commit `6b0f3d762004758f5bd3082d5c500cdf2b711990` was inspected and diffed against the user's installed commit `bea93f7d146092cb72ed7892c3c97174ba7af6ae`. `packages/plugins/message-logger/src` and `settings.ts` are identical between those commits.

The official plugin uses a build-generated SchemaPanel (from settings.ts), Discord-native history action sheets, typed Flux interceptors and in-memory Maps. It keeps deleted messages in Discord's cache by suppressing selected delete actions. It does not store complete message snapshots on disk. Persisting just its ID Maps would not recover text after a restart.

This fork preserves that code. Changes to original files:

- `src/index.tsx`: load the archive before starting official features; flush it after the original stop/purge; close the saved-archive sheet on stop.
- `src/deletions/index.ts`: capture a bounded message snapshot only after original filters accept it, before the original deletion suppression.
- `src/edits/index.ts`: capture before/after text and file names before the original handler mutates attachment arrays. Respect the original attachment toggle.
- `src/history/actions.ts`: explicit message/channel clear actions also clear matching archive records. Synthetic cleanup events keep the original skip/second-delete behavior and do not recapture on stop.
- `settings.ts`, `i18n/en-US.json`: add archive controls to the official generated settings.
- `manifest.json`: separate stable local id, new name/description/version; original authors retained.

New functionality is isolated under `src/archive` with settings button actions in `src/actions.ts`. The original rendering/decorating/row/history implementation and all 38 upstream tests are preserved.

The official `@unbound-app/cli` Rollup sources and settings builders are vendored unmodified. Local package manifests wire the normally internal workspace packages together for npm. The client-build shim-libraries adapter points to a copied upstream JSON file. Bytecode generation is disabled in the project build options; the official JavaScript envelope and runtime-global mapping are used without custom conversion code.

Validation for 0.3.2: 65 Bun tests (39 upstream/rendering, seven storage, six merge, nine integration, four mobile-deletion), 13 Node storage/merge tests, TypeScript checks and official client manifest parser pass. SDK tests use mocks, not an actual Discord/iOS runtime. Do not equate these results with an on-device Reanimated fix. The user confirmed the generated settings and 0.3.0 inline restoration work. The subsequent mobile-deletion guard and color picker still need a live retest.

The npm audit report has two low-severity development-tool findings involving deepmerge through upstream's Rollup resolver. Those tools are used only to build trusted local sources and are not bundled as phone runtime dependencies; no breaking audit downgrade was applied.
