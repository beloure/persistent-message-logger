// Optional verification against an explicitly supplied checkout of the official source.
import { build } from 'esbuild';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import vm from 'node:vm';
const root = resolve(process.argv[2] ?? '../../work/unbound');
const result = await build({
  stdin: { contents: `export { parseAddonManifest } from ${JSON.stringify(resolve(root, 'packages/client/src/addons/manifest.ts'))};`, resolveDir: process.cwd(), loader: 'ts' },
  bundle: true, write: false, platform: 'node', format: 'cjs',
  plugins: [{ name: 'upstream-aliases', setup(b) {
    b.onResolve({ filter: /^(~\/|@unbound-app\/(types|contracts)\/)/ }, args => {
      const path = args.path.startsWith('~/') ? resolve(root, 'packages/client/src', args.path.slice(2)) :
        args.path.startsWith('@unbound-app/types/') ? resolve(root, 'packages/types/typings', args.path.slice('@unbound-app/types/'.length)) :
          resolve(root, 'packages/contracts/src', args.path.slice('@unbound-app/contracts/'.length));
      return { path: path + '.ts' };
    });
  } }],
});
const module = { exports: {} };
vm.runInNewContext(result.outputFiles[0].text, { module, exports: module.exports });
const manifest = JSON.parse(await readFile('dist/manifest.json', 'utf8'));
module.exports.parseAddonManifest(manifest);
console.log('PASS: built manifest accepted by official client parseAddonManifest');
