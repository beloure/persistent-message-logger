import { rollup } from 'rollup';
import { unbound } from '@unbound-app/cli/rollup';
import fs from 'node:fs/promises';
const config = unbound(new URL('./rollup.config.mjs', import.meta.url).href, { bytecode: false, budget: { bundle: '150kb' } });
const bundle = await rollup(config);
try { await bundle.write(config.output as any); } finally { await bundle.close(); }
// Ship complete corresponding source with the hosted release, not device data.
await fs.copyFile('LICENSE', 'dist/LICENSE');
