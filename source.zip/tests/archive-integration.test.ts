import { expect, test } from 'bun:test';
import { flux, fs, metro, render, startPlugin, stopPlugin } from '@unbound-app/api/testing';
import { settings, SettingsPanel } from '@unbound-app/settings';
import { createElement } from 'react';
import { clearSaved, findSaved, archiveState } from '~/archive/runtime';
import { clearMessageHistory } from '~/history/actions';
import { createMessageLog } from '~/log';
import { openSavedArchive } from '~/archive/sheet';
import { ChatManager, RowManager } from './discord';

const previous = { id: '10', channel_id: '20', content: 'Original saved text', author: { id: '30', username: 'Alice' },
  attachments: [{ id: '40', filename: 'notes.txt' }], state: 'SENT' };
const turn = () => new Promise(resolve => setImmediate(resolve));
async function boot() {
  const sheets: { calls: any[][]; openLazy: (...args: any[]) => void; hideActionSheet: () => void } = {
    calls: [], openLazy(...args) { this.calls.push(args); }, hideActionSheet() {},
  };
  metro.register(RowManager); metro.register(ChatManager); metro.register(sheets);
  flux.seed({ Message: { getMessage: (_c: string, id: string) => id === '10' ? previous : undefined,
    getMessages: () => ({ toArray: () => [previous] }) },
    User: { getCurrentUser: () => ({ id: '1' }) }, Channel: { getChannel: () => ({ guild_id: '90' }) } });
  await startPlugin();
  return sheets;
}
test('official deletion behavior and the persistent snapshot work together across restart', async () => {
  settings.archive.persistCapture = true;
  await boot();
  await flux.dispatch({ type: 'MESSAGE_DELETE', id: '10', channelId: '20' });
  await turn();
  expect(findSaved()[0]?.before.content).toBe(previous.content);
  expect(archiveState().status).toBe('Saved locally');
  await stopPlugin();
  expect([...fs.files.values()].some(v => v.includes(previous.content))).toBe(true);
  await boot();
  expect(findSaved()[0]?.before.content).toBe(previous.content);
  await clearSaved();
  await stopPlugin();
  await boot();
  expect(findSaved()).toHaveLength(0);
});
test('edit capture happens before the official handler keeps removed attachments', async () => {
  settings.archive.persistCapture = true;
  await boot();
  await flux.dispatch({ type: 'MESSAGE_UPDATE', message: { id: '10', channel_id: '20',
    content: 'Replacement', edited_timestamp: new Date().toISOString(), attachments: [] } });
  await turn();
  const event = findSaved()[0];
  expect(event?.before.content).toBe(previous.content);
  expect(event?.after?.content).toBe('Replacement');
  expect(event?.before.attachments).toEqual(['notes.txt']);
  expect(event?.after?.attachments).toEqual([]);
});
test('persistent capture starts off while official in-chat logging remains available', async () => {
  await boot();
  expect(settings.archive.persistCapture).toBe(false);
  await flux.dispatch({ type: 'MESSAGE_DELETE', id: '10', channelId: '20' });
  await turn();
  expect(findSaved()).toHaveLength(0);
});
test('official clear history also removes the archived record without recapturing it', async () => {
  settings.archive.persistCapture = true;
  await boot();
  await flux.dispatch({ type: 'MESSAGE_UPDATE', message: { id: '10', channel_id: '20', content: 'Changed', edited_timestamp: new Date().toISOString() } });
  await turn();
  expect(findSaved()).toHaveLength(1);
  clearMessageHistory(createMessageLog(), '20', '10');
  await turn();
  expect(findSaved()).toHaveLength(0);
});
test('generated settings render archive controls and the search viewer opens as an official-style sheet', async () => {
  const sheets = await boot();
  const panel = render(createElement(SettingsPanel));
  expect(panel.text()).toContain('Open saved archive and search');
  openSavedArchive();
  expect(sheets.calls.length).toBeGreaterThan(0);
  const call = sheets.calls.at(-1)!;
  const loaded = await call[0];
  const sheet = render(createElement(loaded.default));
  expect(sheet.text()).toContain('Saved Message Archive');
  expect(sheet.findAll('TextInput')).toHaveLength(2);
});
