# Changelog

## 0.3.2

- Credit Xias (1200834767457894450) alongside the original authors.
- Use Persistent Message Logger consistently as the plugin name.
- Add a deleted-message color picker while retaining the default red highlight.
- Add a color regression test; all 65 SDK tests pass.


## 0.3.1

- Keep a phone-initiated deletion's server confirmation from being treated as Dismiss.
- Preserve explicit local Dismiss and ordinary remote deletion behavior.
- Add four mobile-deletion regression tests; all 64 SDK tests pass.

## 0.3.0

- Restore captured, retained deleted text to its original channel when its history loads, using the official red/deleted decoration.
- Preserve original IDs/order and real messages, with guarded raw/record batch handling and deduplication.
- Apply account separation, retention and current ignore/channel preferences to restoration.
- Make Dismiss remove the saved deletion too; tag local stop/expiry/clear cleanup so it cannot recapture or erase retained records on stop.
- Add bot metadata for new snapshots without breaking existing v1 archives.
- Add six merge tests and four inline integration tests; 60 tests pass in total.

## 0.2.0

- Official-source fork with generated settings and Discord-native history sheets.
- Local persistent archive, search, retention and clear controls.
